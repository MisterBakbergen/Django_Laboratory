from django.shortcuts import render



def index(request):
    return render(request, 'main/index.html')


def pogoda(request):
    return render(request, 'main/pogoda.html')


def about(request):
    return render(request, 'main/about.html')