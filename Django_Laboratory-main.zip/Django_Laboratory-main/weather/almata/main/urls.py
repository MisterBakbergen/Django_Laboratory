from django.urls import path
from . import views

urlpatterns = [
    path('', views.pogoda),              # главная страница -> погода
    path('index', views.index),          # старая главная по адресу /index
    path('about', views.about)
]